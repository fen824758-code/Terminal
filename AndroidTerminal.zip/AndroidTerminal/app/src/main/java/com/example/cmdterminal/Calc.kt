package com.example.cmdterminal

import java.math.BigDecimal
import java.math.MathContext

/** Калькулятор: + - * / ^ ( ) % pi e sqrt abs sin cos tan ln log round floor ceil. */
object Calc {
    fun eval(src: String): Double {
        val p = P(src)
        val v = p.expr()
        if (p.peek() != null) throw IllegalArgumentException("Неожиданный символ '${p.peek()}'")
        return v
    }

    fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return v.toString()
        return BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class P(val s: String) {
        var i = 0

        fun peek(): Char? {
            while (i < s.length && s[i].isWhitespace()) i++
            return if (i < s.length) s[i] else null
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { i++; v += term() }
                else if (c == '-') { i++; v -= term() }
                else break
            }
            return v
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                val c = peek()
                if (c == '*') { i++; v *= unary() }
                else if (c == '/') {
                    i++
                    val d = unary()
                    if (d == 0.0) throw IllegalArgumentException("Деление на ноль")
                    v /= d
                }
                else if (c == '%') { i++; v %= unary() }
                else break
            }
            return v
        }

        fun unary(): Double {
            val c = peek()
            if (c == '-') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return power()
        }

        fun power(): Double {
            val b = primary()
            if (peek() == '^') { i++; return Math.pow(b, unary()) }
            return b
        }

        fun primary(): Double {
            val c = peek() ?: throw IllegalArgumentException("Неожиданный конец выражения")
            var v: Double
            if (c == '(') {
                i++
                v = expr()
                if (peek() != ')') throw IllegalArgumentException("Ожидалась ')'")
                i++
            } else if (c.isDigit() || c == '.') {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                v = s.substring(st, i).toDoubleOrNull() ?: throw IllegalArgumentException("Неверное число")
            } else if (c.isLetter()) {
                val st = i
                while (i < s.length && s[i].isLetter()) i++
                val name = s.substring(st, i).lowercase()
                if (name == "pi") v = Math.PI
                else if (name == "e") v = Math.E
                else {
                    if (peek() != '(') throw IllegalArgumentException("Неизвестное имя '$name'")
                    i++
                    val a = expr()
                    if (peek() != ')') throw IllegalArgumentException("Ожидалась ')'")
                    i++
                    v = fn(name, a)
                }
            } else {
                throw IllegalArgumentException("Неожиданный символ '$c'")
            }
            // 50% -> 0.5 (если после % нет операнда)
            if (peek() == '%') {
                val save = i
                i++
                val n = peek()
                if (n == null || n in "+-*/^)") v /= 100.0 else i = save
            }
            return v
        }

        fun fn(name: String, a: Double): Double = when (name) {
            "sqrt" -> if (a < 0) throw IllegalArgumentException("Корень из отрицательного числа") else Math.sqrt(a)
            "abs" -> Math.abs(a)
            "sin" -> Math.sin(a)
            "cos" -> Math.cos(a)
            "tan" -> Math.tan(a)
            "ln" -> Math.log(a)
            "log" -> Math.log10(a)
            "round" -> Math.round(a).toDouble()
            "floor" -> Math.floor(a)
            "ceil" -> Math.ceil(a)
            else -> throw IllegalArgumentException("Неизвестная функция '$name'")
        }
    }
}
