package com.example.cmdterminal

class Ctx(
    val s: Session,
    val fs: VirtualFS,
    val stdin: String?,
    val out: StringBuilder,
    val err: (String) -> Unit
) {
    fun println(t: String = "") { out.append(t).append('\n') }
}

typealias Cmd = (Ctx, Call) -> Int

/** Единая точка выполнения команд (позже её же будет использовать ИИ). */
object Executor {
    val aliases = mapOf(
        "chdir" to "cd", "md" to "mkdir", "rd" to "rmdir",
        "erase" to "del", "rename" to "ren"
    )

    fun emit(s: Session, text: String) {
        if (text.isEmpty()) return
        val t = if (text.endsWith("\n")) text.dropLast(1) else text
        t.split('\n').forEach { s.lines.add(it) }
    }

    fun execute(s: Session, fs: VirtualFS, rawLine: String) {
        s.lines.add("${s.cwd}>$rawLine")
        s.histPos = -1
        if (rawLine.isBlank()) return
        if (s.history.lastOrNull() != rawLine) s.history.add(rawLine)
        try {
            val chains = Parser.parse(Parser.expand(rawLine, s))
            var prev = ""
            for (ch in chains) {
                val go = when (prev) {
                    "&&" -> s.lastExit == 0
                    "||" -> s.lastExit != 0
                    else -> true
                }
                if (go) s.lastExit = runPipeline(s, fs, ch.pipeline)
                prev = ch.link
            }
        } catch (e: ParseError) {
            emit(s, e.message ?: "Ошибка")
            s.lastExit = 1
        }
        fs.save()
    }

    private fun runPipeline(s: Session, fs: VirtualFS, p: Pipeline): Int {
        var input: String? = null
        var code = 0
        p.cmds.forEachIndexed { i, call ->
            val out = StringBuilder()
            val ctx = Ctx(s, fs, input, out) { msg -> emit(s, msg) }
            code = runCall(ctx, call)
            if (call.redirect != null) {
                try {
                    fs.write(fs.resolve(s.cwd, call.redirectTo ?: ""), out.toString(), call.redirect == ">>")
                } catch (e: FsException) {
                    emit(s, e.message ?: "")
                    code = 1
                }
                input = ""
            } else if (i < p.cmds.size - 1) {
                input = out.toString()
            } else {
                emit(s, out.toString())
            }
        }
        return code
    }

    private fun runCall(c: Ctx, call0: Call): Int {
        var call = call0
        // cd.. и cd\ без пробела
        Regex("^(?i:cd|chdir)(?=[.\\\\/])").find(call.name)?.let { m ->
            val rest = call.name.substring(m.value.length)
            call = Call("cd", listOf(rest) + call.args, listOf(rest) + call.raw, call.redirect, call.redirectTo)
        }
        // echo. и echo:
        Regex("^(?i:echo)(?=[.:])").find(call.name)?.let { m ->
            val rest = call.name.substring(m.value.length + 1)
            call = Call("echo", listOf(rest) + call.args, listOf(rest) + call.raw, call.redirect, call.redirectTo)
        }
        val low = call.name.lowercase()
        if (Regex("^[a-z]:$").matches(low)) {
            if (!low.startsWith("c")) { c.err("Системе не удается найти указанный диск."); return 1 }
            return 0
        }
        val key = aliases[low] ?: low
        val cmd = Commands.table[key]
        if (cmd == null) {
            c.err("'${call.name}' не является внутренней или внешней командой, исполняемой программой или пакетным файлом.")
            return 1
        }
        if ("/?" in call.args) { c.println(Commands.info[key] ?: ""); return 0 }
        return try {
            cmd(c, call)
        } catch (e: FsException) {
            c.err(e.message ?: ""); 1
        } catch (e: Exception) {
            c.err("Ошибка: ${e.message}"); 1
        }
    }
}
