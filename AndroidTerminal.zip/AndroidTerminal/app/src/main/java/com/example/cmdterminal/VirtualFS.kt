package com.example.cmdterminal

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class FsException(msg: String) : Exception(msg)

sealed class Node(var name: String, var modified: Long)

class DirNode(name: String, modified: Long = System.currentTimeMillis()) : Node(name, modified) {
    val children = linkedMapOf<String, Node>() // ключ - имя в нижнем регистре
}

class FileNode(name: String, modified: Long = System.currentTimeMillis(), var content: String = "") :
    Node(name, modified)

/** Виртуальный диск C:\ (хранится в JSON-файле внутри приложения). */
class VirtualFS(private val storage: File?) {
    val root = DirNode("C:")

    init { load() }

    private fun now() = System.currentTimeMillis()

    private fun split(abs: String): List<String> = abs.substring(2).split('\\').filter { it.isNotEmpty() }

    fun join(abs: String, name: String) = if (abs.endsWith("\\")) abs + name else "$abs\\$name"

    fun resolve(cwd: String, input: String): String {
        var rest = input.trim().trim('"').replace('/', '\\')
        val segs = mutableListOf<String>()
        if (rest.length >= 2 && rest[1] == ':') {
            if (!rest.substring(0, 2).equals("C:", ignoreCase = true)) {
                throw FsException("Системе не удается найти указанный диск.")
            }
            rest = rest.substring(2)
            if (!rest.startsWith("\\")) segs.addAll(split(cwd))
        } else if (!rest.startsWith("\\")) {
            segs.addAll(split(cwd))
        }
        for (s in rest.split('\\')) {
            when (s) {
                "", "." -> {}
                ".." -> if (segs.isNotEmpty()) segs.removeAt(segs.size - 1)
                else -> segs.add(s)
            }
        }
        return if (segs.isEmpty()) "C:\\" else "C:\\" + segs.joinToString("\\")
    }

    fun get(abs: String): Node? {
        var cur: Node = root
        for (s in split(abs)) {
            cur = (cur as? DirNode)?.children?.get(s.lowercase()) ?: return null
        }
        return cur
    }

    private fun parent(abs: String): Pair<DirNode, String> {
        val segs = split(abs)
        if (segs.isEmpty()) throw FsException("Недопустимая операция над корнем диска.")
        val pp = "C:\\" + segs.dropLast(1).joinToString("\\")
        val p = get(pp) as? DirNode ?: throw FsException("Системе не удается найти указанный путь.")
        return p to segs.last()
    }

    fun mkdirs(abs: String) {
        var cur = root
        for (s in split(abs)) {
            val ex = cur.children[s.lowercase()]
            cur = when (ex) {
                null -> DirNode(s).also { cur.children[s.lowercase()] = it }
                is DirNode -> ex
                else -> throw FsException("Подпапка или файл $s уже существует.")
            }
        }
    }

    fun write(abs: String, text: String, append: Boolean) {
        val (p, name) = parent(abs)
        when (val ex = p.children[name.lowercase()]) {
            null -> p.children[name.lowercase()] = FileNode(name, content = text)
            is FileNode -> {
                ex.content = if (append) ex.content + text else text
                ex.modified = now()
            }
            else -> throw FsException("Отказано в доступе.")
        }
    }

    fun delete(abs: String) {
        val (p, name) = parent(abs)
        p.children.remove(name.lowercase())
    }

    fun rename(abs: String, newName: String) {
        val (p, key) = parent(abs)
        val node = p.children[key.lowercase()] ?: throw FsException("Системе не удается найти указанный файл.")
        val nk = newName.lowercase()
        if (nk != key.lowercase() && p.children.containsKey(nk)) {
            throw FsException("Подпапка или файл $newName уже существует.")
        }
        p.children.remove(key.lowercase())
        node.name = newName
        node.modified = now()
        p.children[nk] = node
    }

    fun move(src: String, dst: String) {
        val node = get(src) ?: throw FsException("Системе не удается найти указанный файл.")
        val target = if (get(dst) is DirNode) join(dst, node.name) else dst
        if (target.startsWith("$src\\", ignoreCase = true)) throw FsException("Нельзя переместить папку в саму себя.")
        if (get(target) != null) throw FsException("Подпапка или файл уже существует.")
        val (tp, tk) = parent(target)
        val (sp, sk) = parent(src)
        sp.children.remove(sk.lowercase())
        node.name = tk
        tp.children[tk.lowercase()] = node
    }

    // ---- сохранение ----
    private fun toJson(n: Node): JSONObject = JSONObject().apply {
        put("n", n.name)
        put("m", n.modified)
        when (n) {
            is DirNode -> {
                put("d", true)
                val a = JSONArray()
                n.children.values.forEach { a.put(toJson(it)) }
                put("c", a)
            }
            is FileNode -> put("t", n.content)
        }
    }

    private fun fromJson(o: JSONObject): Node =
        if (o.optBoolean("d")) {
            val d = DirNode(o.getString("n"), o.getLong("m"))
            val a = o.getJSONArray("c")
            for (i in 0 until a.length()) {
                val ch = fromJson(a.getJSONObject(i))
                d.children[ch.name.lowercase()] = ch
            }
            d
        } else {
            FileNode(o.getString("n"), o.getLong("m"), o.optString("t", ""))
        }

    fun save() {
        try { storage?.writeText(toJson(root).toString()) } catch (_: Exception) {}
    }

    private fun load() {
        try {
            if (storage != null && storage.exists()) {
                val r = fromJson(JSONObject(storage.readText())) as DirNode
                root.children.putAll(r.children)
                return
            }
        } catch (_: Exception) {}
        mkdirs("C:\\Users\\Android\\Desktop")
        mkdirs("C:\\Users\\Android\\Documents")
        mkdirs("C:\\Users\\Android\\Downloads")
    }
}
