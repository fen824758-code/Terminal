package com.example.cmdterminal

class ParseError(msg: String) : Exception(msg)

class Tok(val value: String, val raw: String, val op: String? = null)
class Call(
    val name: String,
    val args: List<String>,
    val raw: List<String>,
    val redirect: String?,
    val redirectTo: String?
)
class Pipeline(val cmds: List<Call>)
class Chain(val pipeline: Pipeline, val link: String)

object Parser {
    /** Подставляет %VAR%, %CD%, %ERRORLEVEL% и т.д. */
    fun expand(line: String, s: Session): String =
        Regex("%([^%\\s]+)%").replace(line) { m ->
            val k = m.groupValues[1]
            when (k.uppercase()) {
                "CD" -> s.cwd
                "ERRORLEVEL" -> s.lastExit.toString()
                "RANDOM" -> (0..32767).random().toString()
                else -> s.env[k] ?: m.value
            }
        }

    fun tokenize(line: String): List<Tok> {
        val out = mutableListOf<Tok>()
        val v = StringBuilder()
        val r = StringBuilder()
        var inQ = false
        var has = false
        fun flush() {
            if (has) {
                out.add(Tok(v.toString(), r.toString()))
                v.clear(); r.clear(); has = false
            }
        }
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> { inQ = !inQ; has = true; r.append(c) }
                inQ -> { v.append(c); r.append(c); has = true }
                c == ' ' || c == '\t' -> flush()
                c == '^' && i + 1 < line.length -> {
                    i++
                    v.append(line[i]); r.append(line[i]); has = true
                }
                c == '|' || c == '&' || c == '>' -> {
                    flush()
                    val n = if (i + 1 < line.length && line[i + 1] == c) 2 else 1
                    out.add(Tok("", "", c.toString().repeat(n)))
                    i += n - 1
                }
                else -> { v.append(c); r.append(c); has = true }
            }
            i++
        }
        flush()
        return out
    }

    fun parse(line: String): List<Chain> {
        val toks = tokenize(line)
        val chains = mutableListOf<Chain>()
        var cmds = mutableListOf<Call>()
        var words = mutableListOf<Tok>()
        var redir: String? = null
        var redirTo: String? = null
        var pending: String? = null

        fun endCmd() {
            if (words.isEmpty()) throw ParseError("Синтаксическая ошибка команды.")
            val rest = words.drop(1)
            cmds.add(Call(words[0].value, rest.map { it.value }, rest.map { it.raw }, redir, redirTo))
            words = mutableListOf()
            redir = null
            redirTo = null
        }

        for (t in toks) {
            when (t.op) {
                null -> {
                    if (pending != null) { redir = pending; redirTo = t.value; pending = null }
                    else words.add(t)
                }
                ">", ">>" -> pending = t.op
                "|" -> endCmd()
                "&&", "||", "&" -> {
                    endCmd()
                    chains.add(Chain(Pipeline(cmds), t.op ?: ""))
                    cmds = mutableListOf()
                }
                else -> throw ParseError("Синтаксическая ошибка команды.")
            }
        }
        if (pending != null) throw ParseError("Синтаксическая ошибка команды.")
        if (words.isNotEmpty()) endCmd()
        if (cmds.isNotEmpty()) chains.add(Chain(Pipeline(cmds), ""))
        return chains
    }
}
