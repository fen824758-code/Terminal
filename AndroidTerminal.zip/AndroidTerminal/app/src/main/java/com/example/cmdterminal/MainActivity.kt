package com.example.cmdterminal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val fs = VirtualFS(File(filesDir, "vfs.json"))
        setContent { TerminalApp(fs) { finish() } }
    }
}

@Composable
fun TerminalApp(fs: VirtualFS, onQuit: () -> Unit) {
    val tabs = remember { mutableStateListOf(Session(1)) }
    var current by remember { mutableIntStateOf(0) }
    var nextId by remember { mutableIntStateOf(2) }
    if (tabs.isEmpty()) return
    val s = tabs[current.coerceIn(0, tabs.lastIndex)]
    val mono = FontFamily.Monospace

    fun close(i: Int) {
        if (i < 0 || i >= tabs.size) return
        tabs.removeAt(i)
        if (tabs.isEmpty()) { onQuit(); return }
        if (current >= tabs.size) current = tabs.lastIndex else if (i < current) current--
    }
    LaunchedEffect(s.closed) { if (s.closed) close(tabs.indexOf(s)) }

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().imePadding()) {
        // Вкладки
        Row(Modifier.fillMaxWidth().background(Color(0xFF111111)), verticalAlignment = Alignment.Bottom) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                tabs.forEachIndexed { i, t ->
                    Row(
                        Modifier.padding(top = 6.dp, start = 4.dp)
                            .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                            .background(if (t === s) Color(0xFF202020) else Color(0xFF181818))
                            .clickable { current = i }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(t.title, color = Color.White, fontSize = 14.sp, maxLines = 1)
                        Spacer(Modifier.width(10.dp))
                        Text("×", color = Color.LightGray, fontSize = 20.sp, modifier = Modifier.clickable { close(i) })
                    }
                }
            }
            Text(
                "+", color = Color.White, fontSize = 26.sp,
                modifier = Modifier.clickable {
                    val id = nextId
                    nextId = id + 1
                    tabs.add(Session(id))
                    current = tabs.lastIndex
                }.padding(horizontal = 18.dp, vertical = 6.dp)
            )
        }
        // Заголовок
        Box(Modifier.fillMaxWidth().background(Color(0xFF202020)).padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text(s.title, color = Color.White, fontSize = 20.sp, maxLines = 1)
        }

        key(s.id) {
            val listState = rememberLazyListState()
            LaunchedEffect(s.lines.size) {
                if (s.lines.isNotEmpty()) listState.scrollToItem(s.lines.lastIndex)
            }
            SelectionContainer(Modifier.weight(1f).fillMaxWidth().background(s.bg)) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp)) {
                    items(s.lines.size) { i ->
                        val line = s.lines.getOrNull(i) ?: ""
                        Text(
                            if (line.isEmpty()) " " else line,
                            color = s.fg, fontFamily = mono, fontSize = 14.sp, lineHeight = 19.sp
                        )
                    }
                }
            }

            var input by remember { mutableStateOf(TextFieldValue("")) }
            val focus = remember { FocusRequester() }
            LaunchedEffect(s.id) { focus.requestFocus() }

            fun setText(t: String) { input = TextFieldValue(t, TextRange(t.length)) }
            fun insert(t: String) {
                val a = input.selection.min
                val b = input.selection.max
                input = TextFieldValue(input.text.replaceRange(a, b, t), TextRange(a + t.length))
            }
            fun submit() {
                val t = input.text
                input = TextFieldValue("")
                Executor.execute(s, fs, t)
            }
            fun hist(up: Boolean) {
                if (s.history.isEmpty()) return
                var p = s.histPos
                if (up) p = if (p == -1) s.history.lastIndex else maxOf(0, p - 1)
                else { if (p != -1) p++; if (p > s.history.lastIndex) p = -1 }
                s.histPos = p
                setText(if (p == -1) "" else s.history[p])
            }

            // Ряд специальных клавиш
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF1A1A1A)).horizontalScroll(rememberScrollState()).padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                KeyBtn("Tab") { setText(Completer.complete(s, fs, input.text)) }
                KeyBtn("↑") { hist(true) }
                KeyBtn("↓") { hist(false) }
                listOf("\\", "/", ">", "|", "\"", "%", ".", ":").forEach { ch -> KeyBtn(ch) { insert(ch) } }
            }

            // Строка ввода
            Row(
                Modifier.fillMaxWidth().background(s.bg).padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${s.cwd}>", color = s.fg, fontFamily = mono, fontSize = 15.sp)
                Spacer(Modifier.width(6.dp))
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    textStyle = TextStyle(color = s.fg, fontFamily = mono, fontSize = 15.sp),
                    cursorBrush = SolidColor(s.fg),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrect = false,
                        imeAction = ImeAction.Send
                    ),
                    keyboardActions = KeyboardActions(onSend = { submit() }),
                    modifier = Modifier.weight(1f).focusRequester(focus)
                )
            }
        }
    }
}

@Composable
fun KeyBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.defaultMinSize(minWidth = 44.dp).height(42.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF2E2E2E))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 17.sp) }
}
