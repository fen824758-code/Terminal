package com.example.cmdterminal

import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    val info = linkedMapOf<String, String>()
    val table = HashMap<String, Cmd>()
    private val flagRe = Regex("^/[A-Za-z?]$")
    private const val DIRPAD = "    <DIR>           "

    private fun reg(name: String, desc: String, cmd: Cmd) { table[name] = cmd; info[name] = desc }
    private fun flags(call: Call) = call.args.filter { flagRe.matches(it) }.map { it.lowercase() }.toSet()
    private fun params(call: Call) = call.args.filterNot { flagRe.matches(it) }
    private val byName = compareBy<Node>({ it !is DirNode }, { it.name.lowercase() })

    init {
        reg("cd", "CD [путь] - показывает или меняет текущую папку.", this::cd)
        reg("dir", "DIR [путь] [/b] - список файлов и папок.", this::dir)
        reg("mkdir", "MKDIR путь - создаёт папку.", this::mkdir)
        reg("rmdir", "RMDIR [/s] путь - удаляет папку.", this::rmdir)
        reg("copy", "COPY источник [назначение] - копирует файл.", this::copy)
        reg("move", "MOVE источник назначение - перемещает файл или папку.", this::move)
        reg("ren", "REN имя новое_имя - переименовывает.", this::ren)
        reg("del", "DEL файл... - удаляет файлы.", this::del)
        reg("type", "TYPE файл... - показывает содержимое файла.", this::type)
        reg("echo", "ECHO текст - выводит текст (ECHO текст > файл записывает в файл).", this::echo)
        reg("set", "SET [имя=значение] | SET /A выражение - переменные среды.", this::set)
        reg("find", "FIND [/i] [/v] [/c] \"текст\" [файл...] - поиск строк.", this::find)
        reg("sort", "SORT [/r] [файл] - сортировка строк.", this::sort)
        reg("tree", "TREE [путь] [/f] - дерево папок.", this::tree)
        reg("calc", "CALC выражение - калькулятор: + - * / ^ ( ) % pi sqrt sin cos ln log.", this::calc)
        reg("cls", "CLS - очищает экран.", this::cls)
        reg("title", "TITLE текст - меняет заголовок окна.", this::title)
        reg("color", "COLOR [ФТ] - цвета: Ф фон, Т текст (0-9, A-F). Без аргументов: сброс.", this::color)
        reg("ver", "VER - версия терминала.", this::ver)
        reg("date", "DATE - текущая дата.", this::date)
        reg("time", "TIME - текущее время.", this::time)
        reg("whoami", "WHOAMI - имя пользователя.", this::whoami)
        reg("hostname", "HOSTNAME - имя устройства.", this::hostname)
        reg("history", "HISTORY - история команд.", this::history)
        reg("help", "HELP [команда] - справка.", this::help)
        reg("exit", "EXIT - закрывает вкладку.", this::exit)
    }

    private fun resolve(c: Ctx, p: String) = c.fs.resolve(c.s.cwd, p)
    private fun nf(c: Ctx) { c.err("Системе не удается найти указанный путь.") }

    private fun cd(c: Ctx, call: Call): Int {
        val p = params(call).joinToString(" ")
        if (p.isEmpty()) { c.println(c.s.cwd); return 0 }
        val abs = resolve(c, p)
        if (c.fs.get(abs) !is DirNode) { nf(c); return 1 }
        c.s.cwd = abs
        return 0
    }

    private fun dir(c: Ctx, call: Call): Int {
        val fl = flags(call)
        val abs = resolve(c, params(call).joinToString(" ").ifEmpty { "." })
        val n = c.fs.get(abs)
        if (n == null) { c.err("Файл не найден"); return 1 }
        val d = n as? DirNode
        val items: List<Node> = if (d != null) d.children.values.sortedWith(byName) else listOf(n)
        if ("/b" in fl) { items.forEach { c.println(it.name) }; return 0 }
        val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.getDefault())
        val header = if (d != null) abs else abs.substringBeforeLast('\\').let { if (it.endsWith(":")) "$it\\" else it }
        c.println(" Содержимое папки $header")
        c.println()
        if (d != null && abs != "C:\\") {
            val t = fmt.format(Date(d.modified))
            c.println("$t$DIRPAD.")
            c.println("$t$DIRPAD..")
        }
        var files = 0
        var dirs = 0
        var bytes = 0L
        for (node in items) {
            val t = fmt.format(Date(node.modified))
            if (node is DirNode) {
                dirs++
                c.println("$t$DIRPAD${node.name}")
            } else if (node is FileNode) {
                val sz = node.content.toByteArray().size.toLong()
                files++
                bytes += sz
                c.println("$t ${sz.toString().padStart(18)} ${node.name}")
            }
        }
        c.println("${files.toString().padStart(16)} файлов ${bytes.toString().padStart(14)} байт")
        c.println("${dirs.toString().padStart(16)} папок")
        return 0
    }

    private fun mkdir(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.isEmpty()) { c.err("Синтаксис команды неверен."); return 1 }
        var code = 0
        for (p in ps) {
            val abs = resolve(c, p)
            if (c.fs.get(abs) != null) { c.err("Подпапка или файл $p уже существует."); code = 1; continue }
            c.fs.mkdirs(abs)
        }
        return code
    }

    private fun rmdir(c: Ctx, call: Call): Int {
        val rec = "/s" in flags(call)
        val ps = params(call)
        if (ps.isEmpty()) { c.err("Синтаксис команды неверен."); return 1 }
        var code = 0
        for (p in ps) {
            val abs = resolve(c, p)
            val n = c.fs.get(abs)
            if (n !is DirNode) { nf(c); code = 1; continue }
            if (abs == "C:\\") { c.err("Отказано в доступе."); code = 1; continue }
            if (n.children.isNotEmpty() && !rec) { c.err("Папка не пуста."); code = 1; continue }
            c.fs.delete(abs)
            if (c.s.cwd.startsWith(abs, ignoreCase = true)) c.s.cwd = c.fs.resolve(abs, "..")
        }
        return code
    }

    private fun copy(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.isEmpty()) { c.err("Синтаксис команды неверен."); return 1 }
        val src = c.fs.get(resolve(c, ps[0])) as? FileNode
        if (src == null) { c.err("Системе не удается найти указанный файл."); return 1 }
        val dstAbs = resolve(c, if (ps.size > 1) ps[1] else ".")
        val target = if (c.fs.get(dstAbs) is DirNode) c.fs.join(dstAbs, src.name) else dstAbs
        c.fs.write(target, src.content, false)
        c.println("Скопировано файлов: 1.")
        return 0
    }

    private fun move(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.size < 2) { c.err("Синтаксис команды неверен."); return 1 }
        c.fs.move(resolve(c, ps[0]), resolve(c, ps[1]))
        c.println("Перемещено файлов: 1.")
        return 0
    }

    private fun ren(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.size < 2) { c.err("Синтаксис команды неверен."); return 1 }
        if (ps[1].contains('\\') || ps[1].contains('/')) { c.err("Синтаксис команды неверен."); return 1 }
        c.fs.rename(resolve(c, ps[0]), ps[1])
        return 0
    }

    private fun del(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.isEmpty()) { c.err("Синтаксис команды неверен."); return 1 }
        var code = 0
        for (p in ps) {
            val abs = resolve(c, p)
            when (val n = c.fs.get(abs)) {
                is FileNode -> c.fs.delete(abs)
                is DirNode -> n.children.entries.removeAll { it.value is FileNode }
                else -> { c.err("Не удается найти $abs"); code = 1 }
            }
        }
        return code
    }

    private fun type(c: Ctx, call: Call): Int {
        val ps = params(call)
        if (ps.isEmpty()) { c.err("Синтаксис команды неверен."); return 1 }
        var code = 0
        for (p in ps) {
            val n = c.fs.get(resolve(c, p))
            if (n is FileNode) {
                c.out.append(n.content)
                if (n.content.isNotEmpty() && !n.content.endsWith("\n")) c.out.append('\n')
            } else {
                c.err("Системе не удается найти указанный файл: $p")
                code = 1
            }
        }
        return code
    }

    private fun echo(c: Ctx, call: Call): Int {
        if (call.args.isEmpty()) { c.println("ECHO включён."); return 0 }
        c.println(call.raw.joinToString(" "))
        return 0
    }

    private fun set(c: Ctx, call: Call): Int {
        if ("/a" in flags(call)) {
            val expr = call.raw.filterNot { it.equals("/a", true) }.joinToString(" ")
            val eq = expr.indexOf('=')
            if (eq > 0) {
                val v = Calc.fmt(Calc.eval(expr.substring(eq + 1)))
                c.s.env[expr.substring(0, eq).trim()] = v
                c.println(v)
            } else {
                c.println(Calc.fmt(Calc.eval(expr)))
            }
            return 0
        }
        val text = call.raw.joinToString(" ").trim().removeSurrounding("\"")
        if (text.isEmpty()) { c.s.env.forEach { (k, v) -> c.println("$k=$v") }; return 0 }
        val eq = text.indexOf('=')
        if (eq > 0) {
            val name = text.substring(0, eq).trim()
            val value = text.substring(eq + 1)
            if (value.isEmpty()) c.s.env.remove(name) else c.s.env[name] = value
            return 0
        }
        val matches = c.s.env.filterKeys { it.startsWith(text, ignoreCase = true) }
        if (matches.isEmpty()) { c.err("Переменная среды $text не определена."); return 1 }
        matches.forEach { (k, v) -> c.println("$k=$v") }
        return 0
    }

    private fun find(c: Ctx, call: Call): Int {
        val fl = flags(call)
        val ps = params(call)
        if (ps.isEmpty()) { c.err("FIND: Неправильный формат параметра"); return 2 }
        val needle = ps[0]
        val ic = "/i" in fl
        val inv = "/v" in fl
        val cnt = "/c" in fl
        var found = false
        fun scan(lines: List<String>, header: String?) {
            if (header != null) c.println("---------- $header")
            val m = lines.filter { it.contains(needle, ic) != inv }
            if (m.isNotEmpty()) found = true
            if (cnt) c.println(m.size.toString()) else m.forEach { c.println(it) }
        }
        if (ps.size == 1) {
            scan((c.stdin ?: "").lines().dropLastWhile { it.isEmpty() }, null)
        } else {
            for (f in ps.drop(1)) {
                val n = c.fs.get(resolve(c, f))
                if (n is FileNode) scan(n.content.lines().dropLastWhile { it.isEmpty() }, f.uppercase())
                else c.err("Файл не найден - $f")
            }
        }
        return if (found) 0 else 1
    }

    private fun sort(c: Ctx, call: Call): Int {
        val ps = params(call)
        val text: String
        if (ps.isEmpty()) {
            text = c.stdin ?: ""
        } else {
            val n = c.fs.get(resolve(c, ps[0])) as? FileNode
            if (n == null) { c.err("Не удается открыть файл ${ps[0]}"); return 1 }
            text = n.content
        }
        val l = text.lines().dropLastWhile { it.isEmpty() }.sortedWith(String.CASE_INSENSITIVE_ORDER)
        (if ("/r" in flags(call)) l.reversed() else l).forEach { c.println(it) }
        return 0
    }

    private fun tree(c: Ctx, call: Call): Int {
        val abs = resolve(c, params(call).joinToString(" ").ifEmpty { "." })
        val d = c.fs.get(abs) as? DirNode
        if (d == null) { c.err("Недопустимый путь - $abs"); return 1 }
        c.println(abs)
        walk(c, d, "", "/f" in flags(call))
        return 0
    }

    private fun walk(c: Ctx, d: DirNode, prefix: String, files: Boolean) {
        val kids = d.children.values.filter { files || it is DirNode }.sortedWith(byName)
        kids.forEachIndexed { i, k ->
            val last = i == kids.lastIndex
            c.println(prefix + (if (last) "└───" else "├───") + k.name)
            if (k is DirNode) walk(c, k, prefix + (if (last) "    " else "│   "), files)
        }
    }

    private fun calc(c: Ctx, call: Call): Int {
        val expr = if (call.raw.isEmpty()) (c.stdin ?: "").trim() else call.raw.joinToString(" ")
        if (expr.isEmpty()) { c.println("Использование: calc выражение   (например: calc 125 * 8)"); return 1 }
        c.println(Calc.fmt(Calc.eval(expr)))
        return 0
    }

    private fun cls(c: Ctx, call: Call): Int { c.s.lines.clear(); return 0 }

    private fun title(c: Ctx, call: Call): Int {
        c.s.title = call.args.joinToString(" ").ifEmpty { "Командная строка" }
        return 0
    }

    private fun color(c: Ctx, call: Call): Int {
        val a = call.args.firstOrNull()
        if (a == null) { c.s.fg = Palette.color(7); c.s.bg = Palette.color(0); return 0 }
        val d = a.map { it.digitToIntOrNull(16) }
        if (a.length !in 1..2 || d.any { it == null }) { c.err("Недопустимый аргумент цвета."); return 1 }
        if (a.length == 2) {
            val bg = d[0] ?: 0
            val fg = d[1] ?: 7
            if (bg == fg) { c.err("Цвета фона и текста совпадают."); return 1 }
            c.s.bg = Palette.color(bg)
            c.s.fg = Palette.color(fg)
        } else {
            c.s.fg = Palette.color(d[0] ?: 7)
        }
        return 0
    }

    private fun ver(c: Ctx, call: Call): Int { c.println("Командная строка [Версия 0.1, прототип]"); return 0 }

    private fun date(c: Ctx, call: Call): Int {
        c.println("Текущая дата: " + SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date()))
        return 0
    }

    private fun time(c: Ctx, call: Call): Int {
        c.println("Текущее время: " + SimpleDateFormat("HH:mm:ss.SS", Locale.getDefault()).format(Date()))
        return 0
    }

    private fun whoami(c: Ctx, call: Call): Int {
        c.println("android\\" + (c.s.env["USERNAME"] ?: "user").lowercase())
        return 0
    }

    private fun hostname(c: Ctx, call: Call): Int {
        c.println((Build.MODEL ?: "android").replace(' ', '-'))
        return 0
    }

    private fun history(c: Ctx, call: Call): Int {
        c.s.history.forEachIndexed { i, h -> c.println("${i + 1}  $h") }
        return 0
    }

    private fun help(c: Ctx, call: Call): Int {
        val q = call.args.firstOrNull()?.lowercase()
        if (q != null) {
            val t = info[Executor.aliases[q] ?: q]
            if (t == null) { c.err("Эта команда не поддерживается: $q"); return 1 }
            c.println(t)
            return 0
        }
        c.println("Команды (команда /? покажет подсказку):")
        c.println()
        info.forEach { (k, v) -> c.println(k.uppercase().padEnd(10) + v.substringAfter(" - ", v)) }
        c.println()
        c.println("Поддерживаются: > >> | && || ^ \"кавычки\" %переменные%, Tab для автодополнения.")
        return 0
    }

    private fun exit(c: Ctx, call: Call): Int { c.s.closed = true; return 0 }
}

object Completer {
    fun complete(s: Session, fs: VirtualFS, input: String): String {
        val idx = input.lastIndexOf(' ')
        val head = input.substring(0, idx + 1)
        val word = input.substring(idx + 1).trimStart('"')
        val cands: List<String>
        if (idx < 0) {
            cands = (Commands.table.keys + Executor.aliases.keys).filter { it.startsWith(word, true) }.sorted()
        } else {
            val slash = word.lastIndexOfAny(charArrayOf('\\', '/'))
            val dirPart = if (slash >= 0) word.substring(0, slash + 1) else ""
            val namePart = word.substring(slash + 1)
            val d = try { fs.get(fs.resolve(s.cwd, dirPart.ifEmpty { "." })) as? DirNode } catch (e: Exception) { null }
            if (d == null) return input
            cands = d.children.values.filter { it.name.startsWith(namePart, true) }
                .sortedBy { it.name.lowercase() }
                .map { dirPart + it.name + if (it is DirNode) "\\" else "" }
        }
        if (cands.isEmpty()) return input
        if (cands.size == 1) {
            val one = cands[0]
            return head + if (one.contains(' ')) "\"$one\"" else one
        }
        var p = cands[0]
        for (x in cands) { while (!x.startsWith(p, true)) p = p.dropLast(1) }
        return head + p
    }
}
