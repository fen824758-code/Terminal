package com.example.cmdterminal

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import java.util.TreeMap

object Palette {
    private val rgb = longArrayOf(
        0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xAAAA00, 0xCCCCCC,
        0x808080, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
    )
    fun color(i: Int) = Color(0xFF000000L or rgb[i])
}

/** Одна вкладка терминала: своя папка, переменные, история, цвета. */
class Session(val id: Int) {
    var cwd by mutableStateOf("C:\\Users\\Android")
    var title by mutableStateOf("Командная строка")
    var fg by mutableStateOf(Palette.color(7))
    var bg by mutableStateOf(Palette.color(0))
    var closed by mutableStateOf(false)
    val lines = mutableStateListOf<String>()
    val env = TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER)
    val history = mutableListOf<String>()
    var histPos = -1
    var lastExit = 0

    init {
        env["USERNAME"] = "Android"
        env["COMPUTERNAME"] = "ANDROID"
        env["OS"] = "Android"
        lines.add("Командная строка [Версия 0.1, прототип]")
        lines.add("Виртуальный диск C:\\ хранится в памяти приложения.")
        lines.add("Введите help, чтобы увидеть список команд.")
        lines.add("")
    }
}
